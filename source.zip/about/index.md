layout: about
title: about

members:
  member1:
    name: 'Jain Smith'
    desc: 'Curabitur orci massa, convallis id mauris sed, venenatis porttitor'
    img: 'b7.jpg'
  member2:
    name: 'Shan Carter'
    desc: 'Curabitur orci massa, convallis id mauris sed, venenatis porttitor'
    img: 'b10.jpg'
  member3:
    name: 'Jack Dany'
    desc: 'Curabitur orci massa, convallis id mauris sed, venenatis porttitor'
    img: 'b8.jpg'
  member4:
    name: 'Mary Jain'
    desc: 'Curabitur orci massa, convallis id mauris sed, venenatis porttitor'
    img: 'b9.jpg'

otherMembers:
  member1:
    name: 'Morbi convallis urna'
    desc: 'Vivamus sit amet molestie orci. Nullam porttitor porta lobortis. Mauris semper feugiat varius efficitur ex vel tempus blandit.'
  member2:
    name: 'Aliquam pret iumd'
    desc: 'Vivamus sit amet molestie orci. Nullam porttitor porta lobortis. Mauris semper feugiat varius efficitur ex vel tempus blandit.'
  member3:
    name: 'Jack Dany'
    desc: 'Vivamus sit amet molestie orci. Nullam porttitor porta lobortis. Mauris semper feugiat varius efficitur ex vel tempus blandit.'
  member4:
    name: 'Mary Jain'
    desc: 'Vivamus sit amet molestie orci. Nullam porttitor porta lobortis. Mauris semper feugiat varius efficitur ex vel tempus blandit.'
  member5:
    name: 'Jack Dany'
    desc: 'Vivamus sit amet molestie orci. Nullam porttitor porta lobortis. Mauris semper feugiat varius efficitur ex vel tempus blandit.'
  member6:
    name: 'Morbi convallis urna'
    desc: 'Vivamus sit amet molestie orci. Nullam porttitor porta lobortis. Mauris semper feugiat varius efficitur ex vel tempus blandit.'

---

This is a new about page